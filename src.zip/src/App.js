// import logo from './logo.svg';
import './App.css';
import React, { useState, useEffect } from "react";
import axios from "axios";
import UserDetails from "./components/UserDetails";

const App = () => {
 const [users, setUsers] = useState([]);

  useEffect(() => {
    axios.get('https://reqres.in/api/users')
    .then(response => {
       console.log(response.data)
       const { data } = response.data
       setUsers(data)
   })
  }, []);

  return (
    <div className="App">
      <div>
        {users.map(user => (
          <UserDetails key={user.id} {...user} />
        ))}
      </div>
    </div>
  );
};

export default App;

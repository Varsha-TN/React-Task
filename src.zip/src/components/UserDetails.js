import React from "react";

const UserDetails = ({  email }) => {
  return (   
      <div>
        <h2>{email}</h2>
      </div>
  );
};

export default UserDetails;